<?php
$TRANSLATIONS = array(
"Your personal web services. All your files, contacts, calendar and more, in one place." => "شەخسىي تور مۇلازىمىتىڭىز All your files, contacts, calendar and more, in one place.",
"Connect your Calendar" => "يىلنامەڭىزگە باغلاڭ",
"Connect your Contacts" => "ئالاقەداشلىرىڭىزغا باغلاڭ",
"Documentation" => "قوللانما"
);
$PLURAL_FORMS = "nplurals=1; plural=0;";
