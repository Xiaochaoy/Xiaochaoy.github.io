OC.L10N.register(
    "files_external",
    {
    "Personal" : "Persönlich",
    "Username" : "Benutzername",
    "Password" : "Passwort",
    "Save" : "Speichern",
    "Port" : "Port",
    "Location" : "Ort",
    "Host" : "Host",
    "Share" : "Freigeben",
    "Name" : "Name",
    "Folder name" : "Ordner Name",
    "Delete" : "Löschen"
},
"nplurals=2; plural=(n != 1);");
