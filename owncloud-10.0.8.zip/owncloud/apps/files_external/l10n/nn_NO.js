OC.L10N.register(
    "files_external",
    {
    "Personal" : "Personleg",
    "Username" : "Brukarnamn",
    "Password" : "Passord",
    "Save" : "Lagra",
    "Port" : "Port",
    "Region" : "Region/fylke",
    "WebDAV" : "WebDAV",
    "URL" : "Nettstad",
    "Location" : "Stad",
    "ownCloud" : "ownCloud",
    "Host" : "Tenar",
    "Root" : "Rot",
    "Share" : "Del",
    "Name" : "Namn",
    "Folder name" : "Mappenamn",
    "Configuration" : "Innstillingar",
    "Delete" : "Slett",
    "Saved" : "Lagra"
},
"nplurals=2; plural=(n != 1);");
