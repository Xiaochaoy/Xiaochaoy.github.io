OC.L10N.register(
    "files_external",
    {
    "Personal" : "Personal",
    "Username" : "Usuario",
    "Password" : "Clave",
    "Share" : "Compartir",
    "Folder name" : "Nombre del directorio"
},
"nplurals=2; plural=(n != 1);");
