OC.L10N.register(
    "files_external",
    {
    "Personal" : "தனிப்பட்ட",
    "Grant access" : "அனுமதியை வழங்கல்",
    "Username" : "பயனாளர் பெயர்",
    "Password" : "கடவுச்சொல்",
    "Save" : "சேமிக்க ",
    "Port" : "துறை ",
    "Region" : "பிரதேசம்",
    "URL" : "URL",
    "Location" : "இடம்",
    "ownCloud" : "OwnCloud",
    "Host" : "ஓம்புனர்",
    "Share" : "பகிர்வு",
    "Name" : "பெயர்",
    "External Storage" : "வெளி சேமிப்பு",
    "Folder name" : "கோப்புறை பெயர்",
    "Configuration" : "தகவமைப்பு",
    "Delete" : "நீக்குக"
},
"nplurals=2; plural=(n != 1);");
