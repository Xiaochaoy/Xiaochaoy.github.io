OC.L10N.register(
    "files_external",
    {
    "Personal" : "यक्तिगत",
    "Username" : "प्रयोक्ता का नाम",
    "Password" : "पासवर्ड",
    "Save" : "सहेजें",
    "Share" : "साझा करें",
    "Delete" : "हटाना"
},
"nplurals=2; plural=(n != 1);");
