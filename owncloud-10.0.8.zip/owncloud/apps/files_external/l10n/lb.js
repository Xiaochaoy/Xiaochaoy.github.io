OC.L10N.register(
    "files_external",
    {
    "Personal" : "Perséinlech",
    "Saved" : "Gespäichert",
    "Username" : "Benotzernumm",
    "Password" : "Passwuert",
    "Save" : "Späicheren",
    "Port" : "Port",
    "Region" : "Regioun",
    "URL" : "URL",
    "Location" : "Uert",
    "ownCloud" : "ownCloud",
    "Host" : "Host",
    "Share" : "Deelen",
    "Name" : "Numm",
    "Enable encryption" : "Verschlësselung aschalten",
    "External Storage" : "Externt Lager",
    "Folder name" : "Dossiers Numm:",
    "Advanced settings" : "Erweidert Astellungen",
    "Delete" : "Läschen"
},
"nplurals=2; plural=(n != 1);");
